package telas;

import net.miginfocom.swing.MigLayout;
import javax.swing.*;
import java.awt.*;

public class TelaInicial extends JFrame {

    public TelaInicial() {
        setTitle("Bem-vindo");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(380, 250));
        setLayout(new MigLayout("fill, insets 20", "[grow]", "[grow]"));

        JPanel card = new JPanel(new MigLayout(
                "wrap 1, fillx, insets 30",
                "[grow]",
                "[][]20[]"
        ));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel pergunta = new JLabel("Você já possui login?");
        pergunta.setFont(new Font("Arial", Font.BOLD, 20));
        pergunta.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(pergunta, "growx, gaptop 10");

        JPanel buttonPanel = new JPanel(new MigLayout("fill, insets 0", "[grow][grow]", "[]"));
        buttonPanel.setOpaque(false);

        JButton simButton = new JButton("Sim");
        simButton.setFont(new Font("Arial", Font.BOLD, 16));
        simButton.setFocusPainted(false);

        JButton naoButton = new JButton("Não");
        naoButton.setFont(new Font("Arial", Font.BOLD, 16));
        naoButton.setFocusPainted(false);

        buttonPanel.add(simButton, "growx, height 40!");
        buttonPanel.add(naoButton, "growx, height 40!");

        card.add(buttonPanel, "growx");

        add(card, "grow");

        simButton.addActionListener(e -> {
            new TelaLogin().setVisible(true);
            dispose();
        });

        naoButton.addActionListener(e -> {
            new CadastroUsuario().setVisible(true);
            dispose();
        });

        pack();
        setVisible(true);
    }
}
