package telas;

import Modelos.Produto;
import Controller.ProdutoController;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class TelaCadastroP extends JFrame {
    private ProdutoController controller = new ProdutoController();

    public TelaCadastroP() {
        setTitle("Cadastro de Produtos");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new MigLayout("fill, insets 20", "[grow][200]", "[grow]"));
        setLocationRelativeTo(null);

        DefaultListModel<Produto> listaModel = new DefaultListModel<>();
        JList<Produto> lista = new JList<>(listaModel);
        lista.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scroll = new JScrollPane(lista);
        add(scroll, "grow");

        JPanel painelBotoes = new JPanel(new MigLayout("fill, insets 0", "[grow]", "[]10[]10[]"));

        JButton addButton = new JButton("Adicionar");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        painelBotoes.add(addButton, "growx, wrap");

        JButton removerButton = new JButton("Remover");
        removerButton.setFont(new Font("Arial", Font.BOLD, 14));
        painelBotoes.add(removerButton, "growx, wrap");

        JButton logoutButton = new JButton("Deslogar");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        painelBotoes.add(logoutButton, "growx");

        add(painelBotoes, "grow");

        List<Produto> produtos = controller.listarProdutos();
        for (Produto p : produtos) listaModel.addElement(p);

        addButton.addActionListener(e -> {
            String nome = JOptionPane.showInputDialog(this, "Nome do produto:");
            String preco = JOptionPane.showInputDialog(this, "Preço:");
            String estoque = JOptionPane.showInputDialog(this, "Estoque:");
            try {
                Produto novo = controller.adicionarProduto(nome, preco, estoque);
                listaModel.addElement(novo);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        removerButton.addActionListener(e -> {
            Produto sel = lista.getSelectedValue();
            if (sel == null) return;
            try {
                controller.removerProduto(sel.getId());
                listaModel.removeElement(sel);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        logoutButton.addActionListener(e -> {
            new TelaLogin().setVisible(true);
            dispose();
        });

        setVisible(true);
    }
}