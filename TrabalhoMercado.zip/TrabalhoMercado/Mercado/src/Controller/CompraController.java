package Controller;

import Modelos.Produto;
import Modelos.Usuario;
import dao.CompraDAO;
import dao.ProdutoDAO;

import javax.swing.*;

public class CompraController {

    private ProdutoDAO produtoDAO = new ProdutoDAO();
    private CompraDAO compraDAO = new CompraDAO();

    public java.util.List<Produto> listarProdutos() {
        return produtoDAO.listar();
    }

    public int adicionarProdutoNaSacola(Produto produto, String qtdStr) throws Exception {
        try {
            if (qtdStr == null || qtdStr.trim().isEmpty()) throw new Exception("Quantidade inválida");

            int qtd = Integer.parseInt(qtdStr);

            if (qtd <= 0) throw new Exception("Quantidade deve ser maior que zero");
            if (qtd > produto.getEstoque()) throw new Exception("Estoque insuficiente. Disponível: " + produto.getEstoque());

            int novoEstoque = produto.getEstoque() - qtd;
            produtoDAO.atualizarEstoque(produto.getId(), novoEstoque);
            produto.setEstoque(novoEstoque);

            return qtd;
        } catch (NumberFormatException e) {
            throw new Exception("Digite apenas números");
        }
    }

    public void removerDaSacola(Produto produto) throws Exception {
        try {
            int novoEstoque = produto.getEstoque() + 1;
            produtoDAO.atualizarEstoque(produto.getId(), novoEstoque);
            produto.setEstoque(novoEstoque);
        } catch (Exception e) {
            throw new Exception("Erro ao remover item");
        }
    }

    public void concluirCompra(Usuario usuario, DefaultListModel<Produto> sacola) throws Exception {
        try {
            for (int i = 0; i < sacola.size(); i++) {
                Produto p = sacola.get(i);
                compraDAO.registrarCompra(usuario.getId(), p.getId(), 1);
            }
        } catch (Exception e) {
            throw new Exception("Erro ao concluir a compra");
        }
    }
}
