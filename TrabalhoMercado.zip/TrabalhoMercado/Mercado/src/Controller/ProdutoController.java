package Controller;

import Modelos.Produto;
import dao.ProdutoDAO;

import java.util.List;

public class ProdutoController {

    private ProdutoDAO dao = new ProdutoDAO();

    public Produto adicionarProduto(String nome, String precoStr, String estoqueStr) throws Exception {
        try {
            if (nome == null || nome.trim().isEmpty()) throw new Exception("Nome inválido");

            if (precoStr == null || precoStr.trim().isEmpty()) throw new Exception("Preço inválido");
            double preco = Double.parseDouble(precoStr.replace(",", "."));

            if (estoqueStr == null || estoqueStr.trim().isEmpty()) throw new Exception("Estoque inválido");
            int estoque = Integer.parseInt(estoqueStr);

            if (estoque < 0) throw new Exception("Estoque não pode ser negativo");

            Produto p = new Produto(nome, preco, estoque);
            dao.inserir(p);
            return p;
        } catch (NumberFormatException e) {
            throw new Exception("Valores numéricos inválidos");
        } catch (Exception e) {
            throw e;
        }
    }

    public void removerProduto(int id) throws Exception {
        try {
            dao.remover(id);
        } catch (Exception e) {
            throw new Exception("Erro ao remover produto");
        }
    }

    public List<Produto> listarProdutos() {
        return dao.listar();
    }
}
