package telas;

import Modelos.Produto;
import Modelos.Usuario;
import dao.CompraDAO;
import dao.ProdutoDAO;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class TelaCompra extends JFrame {

    public TelaCompra(Usuario usuario) {
        setTitle("Compra");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);

        DefaultListModel<Produto> listaProdutosModel = new DefaultListModel<>();
        JList<Produto> listaProdutos = new JList<>(listaProdutosModel);
        listaProdutos.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollProdutos = new JScrollPane(listaProdutos);
        scrollProdutos.setBounds(30, 30, 450, 400);
        add(scrollProdutos);

        JLabel quantidadeLabel = new JLabel("Quantidade:");
        quantidadeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        quantidadeLabel.setBounds(500, 30, 100, 30);
        add(quantidadeLabel);

        JTextField quantidadeField = new JTextField();
        quantidadeField.setBounds(600, 30, 100, 30);
        add(quantidadeField);

        JButton comprarButton = new JButton("Adicionar à Compra");
        comprarButton.setFont(new Font("Arial", Font.BOLD, 14));
        comprarButton.setBounds(500, 80, 200, 50);
        add(comprarButton);

        DefaultListModel<Produto> sacolaModel = new DefaultListModel<>();
        JList<Produto> sacolaList = new JList<>(sacolaModel);
        sacolaList.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollSacola = new JScrollPane(sacolaList);
        scrollSacola.setBounds(30, 450, 450, 100);
        add(scrollSacola);

        JButton removerButton = new JButton("Remover da Compra");
        removerButton.setFont(new Font("Arial", Font.BOLD, 14));
        removerButton.setBounds(500, 150, 200, 50);
        add(removerButton);

        JButton concluirButton = new JButton("Concluir Compra");
        concluirButton.setFont(new Font("Arial", Font.BOLD, 14));
        concluirButton.setBounds(500, 220, 200, 50);
        add(concluirButton);

        JLabel totalLabel = new JLabel("Total: 0.0");
        totalLabel.setFont(new Font("Arial", Font.BOLD, 16));
        totalLabel.setBounds(500, 290, 200, 40);
        add(totalLabel);

        ProdutoDAO produtoDAO = new ProdutoDAO();
        List<Produto> produtos = produtoDAO.listar();
        for (Produto p : produtos) listaProdutosModel.addElement(p);

        CompraDAO compraDAO = new CompraDAO();
        final double[] total = {0};

        comprarButton.addActionListener(e -> {
            Produto sel = listaProdutos.getSelectedValue();
            if (sel != null) {
                try {
                    int qtd = Integer.parseInt(quantidadeField.getText().trim());
                    if (qtd <= 0) {
                        JOptionPane.showMessageDialog(this, "Quantidade inválida");
                        return;
                    }
                    if (qtd > sel.getEstoque()) {
                        JOptionPane.showMessageDialog(this, "Estoque insuficiente. Disponível: " + sel.getEstoque());
                        return;
                    }
                    total[0] += sel.getPreco() * qtd;
                    for (int i = 0; i < qtd; i++) sacolaModel.addElement(sel);
                    sel.setEstoque(sel.getEstoque() - qtd);
                    produtoDAO.atualizarEstoque(sel.getId(), sel.getEstoque());
                    listaProdutos.repaint();
                    quantidadeField.setText("");
                    totalLabel.setText("Total: " + total[0]);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Digite um número válido");
                }
            }
        });

        removerButton.addActionListener(e -> {
            Produto sel = sacolaList.getSelectedValue();
            if (sel != null) {
                sacolaModel.removeElement(sel);
                total[0] -= sel.getPreco();
                sel.setEstoque(sel.getEstoque() + 1);
                produtoDAO.atualizarEstoque(sel.getId(), sel.getEstoque());
                listaProdutos.repaint();
                totalLabel.setText("Total: " + total[0]);
            }
        });

        concluirButton.addActionListener(e -> {
            for (int i = 0; i < sacolaModel.size(); i++) {
                Produto p = sacolaModel.get(i);
                compraDAO.registrarCompra(usuario.getId(), p.getId(), 1);
            }
            new Despedida(usuario.getNome(), total[0]).setVisible(true);
            dispose();
        });

        setVisible(true);
    }
}
