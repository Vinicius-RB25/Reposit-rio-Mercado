package Controller;

import Modelos.Usuario;
import dao.UsuarioDAO;
import telas.TelaLogin;

import javax.swing.*;

public class UsuarioController {

    public void cadastrarUsuario(String nome, String cpf, boolean admin, JFrame tela) {
        try {

            if (nome == null || nome.trim().isEmpty())
                throw new Exception("Nome não pode estar vazio.");

            if (cpf == null || cpf.contains("_"))
                throw new Exception("CPF inválido.");

            Usuario usuario = new Usuario(nome, cpf, admin);
            UsuarioDAO dao = new UsuarioDAO();

            boolean sucesso = dao.inserir(usuario);

            if (!sucesso)
                throw new Exception("Erro ao salvar no banco.");

            JOptionPane.showMessageDialog(tela, "Usuário cadastrado com sucesso!");
            new TelaLogin().setVisible(true);
            tela.dispose();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    tela,
                    e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
