package telas;

import java.awt.Font;
import java.text.ParseException;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import Modelos.Usuario;
import dao.UsuarioDAO;
import net.miginfocom.swing.MigLayout;

public class TelaLogin extends JFrame {

    public TelaLogin() {
        setTitle("Login");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new MigLayout("fill, insets 20", "[right][grow, fill]", "[]15[]15[]15[]15[]"));
        setLocationRelativeTo(null);

        JLabel lNome = new JLabel("Nome:");
        lNome.setFont(new Font("Arial", Font.PLAIN, 16));
        add(lNome);

        JTextField nomeField = new JTextField();
        add(nomeField, "wrap");

        JLabel lCpf = new JLabel("CPF:");
        lCpf.setFont(new Font("Arial", Font.PLAIN, 16));
        add(lCpf);

        final JFormattedTextField cpfField;
        try {
            MaskFormatter mask = new MaskFormatter("###.###.###-##");
            mask.setPlaceholderCharacter('_');
            cpfField = new JFormattedTextField(mask);
            add(cpfField, "wrap");
        } catch (ParseException e) {
            throw new RuntimeException("Erro ao criar campo CPF", e);
        }

        JCheckBox adminCheck = new JCheckBox("Administrador");
        adminCheck.setFont(new Font("Arial", Font.PLAIN, 14));
        add(adminCheck, "skip 1, wrap");

        JPanel buttonPanel = new JPanel(new MigLayout("fill, insets 0", "[grow][grow]", "[]"));
        
        JButton entrarButton = new JButton("Entrar");
        entrarButton.setFont(new Font("Arial", Font.BOLD, 16));
        buttonPanel.add(entrarButton, "grow");

        JButton cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.setFont(new Font("Arial", Font.BOLD, 16));
        buttonPanel.add(cadastrarButton, "grow");

        add(buttonPanel, "span 2, grow, gaptop 10");

        entrarButton.addActionListener(e -> {
            String nome = nomeField.getText().trim();
            String cpf = cpfField.getText().trim();

            if (nome.isEmpty() || cpf.contains("_")) {
                JOptionPane.showMessageDialog(this, "Preencha todos os campos corretamente!", "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            UsuarioDAO usuarioDAO = new UsuarioDAO();
            Usuario usuario = usuarioDAO.autenticar(nome, cpf);

            if (usuario != null) {
                if (usuario.isAdministrador()) {
                    new TelaCadastroP().setVisible(true);
                } else {
                    new TelaCompra(usuario).setVisible(true);
                }
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Usuário não encontrado!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        cadastrarButton.addActionListener(e -> {
            new CadastroUsuario().setVisible(true);
            dispose();
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new TelaLogin();
    }
}