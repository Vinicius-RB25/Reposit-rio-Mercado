package telas;

import net.miginfocom.swing.MigLayout;
import javax.swing.*;
import java.awt.*;

public class TelaInicial extends JFrame {
    public TelaInicial() {
        setTitle("Bem-vindo");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new MigLayout("fill, insets 20", "[grow]", "[]20[]"));
        setLocationRelativeTo(null);

        JLabel pergunta = new JLabel("Você já possui login?");
        pergunta.setFont(new Font("Arial", Font.BOLD, 16));
        pergunta.setHorizontalAlignment(SwingConstants.CENTER);
        add(pergunta, "wrap, align center");

        JPanel buttonPanel = new JPanel(new MigLayout("fill, insets 0", "[grow][grow]", "[]"));
        
        JButton simButton = new JButton("Sim");
        buttonPanel.add(simButton, "grow, w 100!");

        JButton naoButton = new JButton("Não");
        buttonPanel.add(naoButton, "grow, w 100!");

        add(buttonPanel, "grow, align center");

        simButton.addActionListener(e -> {
            new TelaLogin().setVisible(true);
            dispose();
        });

        naoButton.addActionListener(e -> {
            new CadastroUsuario().setVisible(true);
            dispose();
        });

        setVisible(true);
    }
}