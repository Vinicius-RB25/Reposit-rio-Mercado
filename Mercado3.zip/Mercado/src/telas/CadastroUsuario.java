package telas;

import Modelos.Usuario;
import Controller.UsuarioController;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.text.ParseException;

public class CadastroUsuario extends JFrame {
    public CadastroUsuario() {
        setTitle("Cadastro de Usuário");
        setSize(500, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new MigLayout("fill, insets 20", "[right][grow, fill]", "[]15[]15[]15[]"));
        setLocationRelativeTo(null);

        JLabel lNome = new JLabel("Nome:");
        lNome.setFont(new Font("Arial", Font.PLAIN, 16));
        add(lNome);

        JTextField nomeField = new JTextField();
        add(nomeField, "wrap");

        JLabel lCpf = new JLabel("CPF:");
        lCpf.setFont(new Font("Arial", Font.PLAIN, 16));
        add(lCpf);

        JFormattedTextField cpfField = null;
        try {
            MaskFormatter cpfMask = new MaskFormatter("###.###.###-##");
            cpfMask.setPlaceholderCharacter('_');
            cpfField = new JFormattedTextField(cpfMask);
            add(cpfField, "wrap");
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Erro ao formatar CPF", "Erro", JOptionPane.ERROR_MESSAGE);
        }

        JCheckBox adminCheck = new JCheckBox("Administrador");
        adminCheck.setFont(new Font("Arial", Font.PLAIN, 14));
        add(adminCheck, "skip 1, wrap");

        JButton cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.setFont(new Font("Arial", Font.BOLD, 16));
        add(cadastrarButton, "skip 1, growx, gaptop 10");

        UsuarioController controller = new UsuarioController();
        JFormattedTextField finalCpfField = cpfField;
        cadastrarButton.addActionListener(e -> {
            controller.cadastrarUsuario(
                    nomeField.getText(),
                    finalCpfField.getText(),
                    adminCheck.isSelected(),
                    this
            );
        });

        setVisible(true);
    }
}