package telas;

public class Main {
    public static void main(String[] args) {
        new TelaInicial();
    }
}
