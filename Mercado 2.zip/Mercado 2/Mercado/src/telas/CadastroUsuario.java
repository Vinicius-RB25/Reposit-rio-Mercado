package telas;

import Modelos.Usuario;
import Controller.UsuarioController;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.text.ParseException;

public class CadastroUsuario extends JFrame {

    public CadastroUsuario() {
        setTitle("Cadastro de Usuário");
        setSize(500, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lNome = new JLabel("Nome:");
        lNome.setFont(new Font("Arial", Font.PLAIN, 16));
        lNome.setBounds(50, 50, 100, 30);
        add(lNome);

        JTextField nomeField = new JTextField();
        nomeField.setBounds(180, 50, 250, 30);
        add(nomeField);

        JLabel lCpf = new JLabel("CPF:");
        lCpf.setFont(new Font("Arial", Font.PLAIN, 16));
        lCpf.setBounds(50, 100, 100, 30);
        add(lCpf);

        JFormattedTextField cpfField = null;
        try {
            MaskFormatter cpfMask = new MaskFormatter("###.###.###-##");
            cpfMask.setPlaceholderCharacter('_');
            cpfField = new JFormattedTextField(cpfMask);
            cpfField.setBounds(180, 100, 250, 30);
            add(cpfField);
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Erro ao formatar CPF", "Erro", JOptionPane.ERROR_MESSAGE);
        }

        JCheckBox adminCheck = new JCheckBox("Administrador");
        adminCheck.setFont(new Font("Arial", Font.PLAIN, 14));
        adminCheck.setBounds(180, 150, 200, 30);
        add(adminCheck);

        JButton cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.setFont(new Font("Arial", Font.BOLD, 16));
        cadastrarButton.setBounds(180, 200, 150, 40);
        add(cadastrarButton);

        UsuarioController controller = new UsuarioController();
        JFormattedTextField finalCpfField = cpfField;

        cadastrarButton.addActionListener(e -> {
            controller.cadastrarUsuario(
                    nomeField.getText(),
                    finalCpfField.getText(),
                    adminCheck.isSelected(),
                    this
            );
        });

        setVisible(true);
    }
}
